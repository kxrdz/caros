# Install script for directory: /home/madbad/Development/gitsvn/code/data/data/img/osg-hud

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/home/madbad/Giochi/speed-dreams")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Debug")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "0")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set default install directory permissions.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/games/speed-dreams-2/data/img/osg-hud" TYPE FILE FILES
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/DESIGN.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/abs-icon-normal.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/board-current.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/board-first.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/board-normal.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/dash-items.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/delta-gaining.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/delta-losing.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/delta-normal.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/driverinput-brake.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/driverinput-clutch.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/driverinput-container.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/driverinput-empty.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/driverinput-throttle.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/driverinput-wheel.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/engine-icon-damaged.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/engine-icon.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/fuel-icon-empty.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/fuel-icon-full.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/fuel-info-container.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/gforces-dot.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/gforces-graph.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/lap-container.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/laptime-container-green.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/laptime-container-grey.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/laptime-container-red.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/laptime-container-violet.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/laptime-container.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/position-container.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/relative-time-container.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/rpm-off.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/rpm-on.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tachometer.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/times-container.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-cold-left.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-cold-middle.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-cold-right.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-cold.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-degradation-off.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-degradation-on.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-hot-left.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-hot-middle.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-hot-right.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-hot.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-optimal-left.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-optimal-middle.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-optimal-right.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-optimal.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-slip-indicator.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tire-temps-background.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/tractioncontrol-icon-normal.png"
    "/home/madbad/Development/gitsvn/code/data/data/img/osg-hud/hudtest.svg"
    )
endif()

